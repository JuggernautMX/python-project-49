### Hexlet tests and linter status:
[![Actions Status](https://github.com/JuggernautMX/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/JuggernautMX/python-project-49/actions)

### Other badges
[![Maintainability](https://api.codeclimate.com/v1/badges/7106e3c9c3fafdbc1f3c/maintainability)](https://codeclimate.com/github/JuggernautMX/python-project-49/maintainability)

### Demos
brain-even
[![brain-even demo](https://github.com/JuggernautMX/python-project-49/blob/main/brain-even.gif)](https://asciinema.org/a/vjMM8K7eKpvIx2IomFuLb57yW)

brain-calc
[![brain-calc demo](https://github.com/JuggernautMX/python-project-49/blob/main/brain-calc.gif)](https://asciinema.org/a/YcadSSP420lW2fD3PvTbakB4F)

brain-gcd
[![brain-gcd demo](https://github.com/JuggernautMX/python-project-49/blob/main/brain-gcd.gif)](https://asciinema.org/a/2WsxacKNsYQu42DRR4GvfA1Nf)
